<template>
  <div>
    CommentList
    <!-- v-for 사용해서 하나씩 코멘트 리스트 아이템으로 만들어 표시해보기 -->
    <ul>
        <li>

        </li>
    </ul>
  </div>
</template>

<script>
export default {
    name: 'CommentList',
    computed: {
      
    }
}
</script>

<style>

</style>