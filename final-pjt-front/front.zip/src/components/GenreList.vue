<template>
  <div></div>
</template>

<script>
export default {
  name: 'GenreList',
  computed: '',
}
</script>

<style></style>
