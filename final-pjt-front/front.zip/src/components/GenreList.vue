<template>
  <div></div>
</template>

<script>
export default {
  name: 'GenreList',
}
</script>

<style></style>
